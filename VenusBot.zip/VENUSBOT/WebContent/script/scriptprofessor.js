var iniciar;
var sobre;
var materia;

window.onload = function() {
	iniciar = document.getElementById("idDivIniciar");
	sobre = document.getElementById("idDivSobre");
	header = document.getElementById("idHeadRespIniciar");
	
	

	var bt1 = document.getElementById("idBt1");
	bt1.onclick = mostrarDivIiniciar
	var bt3 = document.getElementById("idBt3");
	bt3.onclick = mostrarDivSobre

	sobre.classList.add("OcultarNavegacao");
	header.style.height = "133px";
}

function mostrarDivIiniciar() {
	iniciar.classList.remove("OcultarNavegacao");
	sobre.classList.add("OcultarNavegacao");
}
function mostrarDivSobre() {
	iniciar.classList.add("OcultarNavegacao");
	sobre.classList.remove("OcultarNavegacao");
}

//function diminuir(){
//	header.style.height = '133px';
//}
