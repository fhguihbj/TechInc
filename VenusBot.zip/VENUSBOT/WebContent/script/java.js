var iniciar;
var contato;
var sobre;
var materia;

window.onload = function() {
	iniciar = document.getElementById("idDivIniciar");
	contato = document.getElementById("idDivContato");
	sobre = document.getElementById("idDivSobre");

	var bt1 = document.getElementById("idBt1");
	bt1.onclick = mostrarDivIiniciar
	var bt2 = document.getElementById("idBt2");
	bt2.onclick = mostrarDivIContato
	var bt3 = document.getElementById("idBt3");
	bt3.onclick = mostrarDivSobre

	iniciar.classList.add("OcultarNavegacao");
	contato.classList.add("OcultarNavegacao");
	
}

function mostrarDivIiniciar() {
	iniciar.classList.remove("OcultarNavegacao");
	contato.classList.add("OcultarNavegacao");
	sobre.classList.add("OcultarNavegacao");
}
function mostrarDivIContato() {
	iniciar.classList.add("OcultarNavegacao");
	contato.classList.remove("OcultarNavegacao");
	sobre.classList.add("OcultarNavegacao");
}
function mostrarDivSobre() {
	iniciar.classList.add("OcultarNavegacao");
	contato.classList.add("OcultarNavegacao");
	sobre.classList.remove("OcultarNavegacao");
}
function corRazao() {
	document.getElementById("certoRazao").style.color = "#00FF00";
	document.getElementById("certoRazao2").style.color = "#00FF00";
	document.getElementById("certoRazao3").style.color = "#00FF00";
	document.getElementById("certoRazao4").style.color = "#00FF00";
}
function corVolume() {
	document.getElementById("certoVolume").style.color = "#00FF00";
	document.getElementById("certoVolume2").style.color = "#00FF00";
	document.getElementById("certoVolume3").style.color = "#00FF00";
	document.getElementById("certoVolume4").style.color = "#00FF00";
}
function corFuncao () {
	document.getElementById("certoFuncao").style.color = "#00FF00";
	document.getElementById("certoFuncao2").style.color = "#00FF00";
	document.getElementById("certoFuncao3").style.color = "#00FF00";
	document.getElementById("certoFuncao4").style.color = "#00FF00";
}
function corArea () {
	document.getElementById("certoArea").style.color = "#00FF00";
	document.getElementById("certoArea2").style.color = "#00FF00";
	document.getElementById("certoArea3").style.color = "#00FF00";
	document.getElementById("certoArea4").style.color = "#00FF00";
	
}


